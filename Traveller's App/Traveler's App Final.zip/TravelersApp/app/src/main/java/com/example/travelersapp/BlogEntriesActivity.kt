package com.example.travelersapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.travelersapp.databinding.BlogEntriesScreenBinding

class BlogEntriesActivity : AppCompatActivity() {
    private lateinit var binding: BlogEntriesScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = BlogEntriesScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    fun callNewBlogEntryScreen(view: View){
        intent = Intent(this, NewBlogEntryActivity::class.java)
        startActivity(intent)
    }

    fun callMainScreen(view: View){
        intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}