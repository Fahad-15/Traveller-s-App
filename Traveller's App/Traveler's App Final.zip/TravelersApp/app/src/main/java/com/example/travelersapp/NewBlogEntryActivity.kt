package com.example.travelersapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.travelersapp.databinding.NewBlogEntryScreenBinding

class NewBlogEntryActivity : AppCompatActivity() {
    private lateinit var binding: NewBlogEntryScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = NewBlogEntryScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    fun callBlogEntriesScreen(view:View){
        intent = Intent(this, BlogEntriesActivity::class.java)
        startActivity(intent)
    }

    fun callAddPictureScreen(view: View){
        intent = Intent(this, AddPictureActivity::class.java)
        startActivity(intent)
    }
}