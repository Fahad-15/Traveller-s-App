package com.example.travelersapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.travelersapp.databinding.AddingPictureScreenBinding

class AddPictureActivity : AppCompatActivity() {
    private lateinit var binding: AddingPictureScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = AddingPictureScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }
}