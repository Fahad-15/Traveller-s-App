package com.example.travelersapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.travelersapp.databinding.RegisterUserScreenBinding

class RegisterActivity : AppCompatActivity() {
    private lateinit var binding: RegisterUserScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = RegisterUserScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    fun goToMainScreen(view: View){
        intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }

}