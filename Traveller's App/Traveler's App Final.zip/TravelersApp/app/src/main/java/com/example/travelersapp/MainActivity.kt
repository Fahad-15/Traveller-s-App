package com.example.travelersapp

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.example.travelersapp.databinding.LoginScreenBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: LoginScreenBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = LoginScreenBinding.inflate(layoutInflater)
        setContentView(binding.root)
    }

    fun callRegisterScreen(view: View){
        intent = Intent(this, RegisterActivity::class.java)
        startActivity(intent)
    }

    fun callBlogEntries(view: View){
        intent = Intent(this, BlogEntriesActivity::class.java)
        startActivity(intent)
    }
}
